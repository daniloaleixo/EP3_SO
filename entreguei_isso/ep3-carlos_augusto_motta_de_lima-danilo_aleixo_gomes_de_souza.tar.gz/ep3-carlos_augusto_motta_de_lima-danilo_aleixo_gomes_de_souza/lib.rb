# ************************************

  # EP3 - Sistemas Operacionais
  # Prof. Daniel Batista

  # Danilo Aleixo Gomes de Souza
  # n USP: 7972370

  # Carlos Augusto Motta de Lima
  # n USP: 7991228

# *************************************


# importa todos os arquivos necessários para o funcionamento do programa
require './bitarray'
require './process_list'
require './process'
require './memory_manager'
require './memory_page'
require './time_event'
require './time_manager'
