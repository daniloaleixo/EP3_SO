# importa todos os arquivos necessários para o funcionamento do programa
require './vmemory_segment'
require './file_manager'
require './trace_file_data'
require './trace_line'
require './memory_manager'
require './memory_page'
require './time_event'
require './time_manager'